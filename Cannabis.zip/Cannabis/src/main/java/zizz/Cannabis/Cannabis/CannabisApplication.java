package zizz.Cannabis.Cannabis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CannabisApplication {

	public static void main(String[] args) {
		SpringApplication.run(CannabisApplication.class, args);
	}

}
